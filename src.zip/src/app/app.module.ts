import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; 
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TheatreComponent } from './theatre/theatre.component';
import { ScreenComponent } from './screen/screen.component';
import { ShowComponent } from './show/show.component';
import { SeatComponent } from './seat/seat.component';
import { TicketComponent } from './ticket/ticket.component';
import { MovieComponent } from './movie/movie.component';
import { BookingComponent } from './booking/booking.component';
import { BookingStatusComponent } from './booking-status/booking-status.component';
import { UserComponent } from './user/user.component';
import { BookticketComponent } from './bookticket/bookticket.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    TheatreComponent,
    ScreenComponent,
    ShowComponent,
    SeatComponent,
    TicketComponent,
    MovieComponent,
    BookingComponent,
    BookingStatusComponent,
    UserComponent,
    BookticketComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 



}
