import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './classes/User';
@Injectable({
  providedIn: 'root'
})
export class MovieserviceService {
  private baseUrl = 'http://localhost:8050/user/all'
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'my-auth-token'
    })
  };
  constructor(private http: HttpClient) { }

price(ticket:number)
{
  return this.http.get(`${this.baseUrl}/${ticket}`);
}

  addUser(user: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`,user);
  }

 viewTicket(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
   }
  

 
}
