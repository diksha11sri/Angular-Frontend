import { Component, OnInit } from '@angular/core';
import { User } from '../classes/User';
import { MovieserviceService } from '../movieservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  user: User = new User();
  submitted = false;

  constructor(private movieservice: MovieserviceService ,
    private router: Router) { }

  ngOnInit() {
  }

  newUser(): void {
    this.submitted = false;
    this.user = new User();
  }

  save() {
    this.movieservice.addUser(this.user)
      .subscribe(data => console.log(data), error => console.log(error));
    this.user = new User();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
    alert("Booking Successfully");
  }

  gotoList() {
    this.router.navigate(['/theatre']);
  }
}
 
