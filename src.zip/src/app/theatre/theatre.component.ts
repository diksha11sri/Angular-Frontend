import { Component, OnInit } from '@angular/core';
import { User } from '../classes/User';
import { MovieserviceService } from '../movieservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-theatre',
  templateUrl: './theatre.component.html',
  styleUrls: ['./theatre.component.css']
})
export class TheatreComponent implements OnInit {

  users: Observable<User[]>;

  constructor(private movieservice: MovieserviceService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.users= this.movieservice.viewTicket();
  }

  


  

}
