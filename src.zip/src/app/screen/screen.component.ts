import { Component, OnInit } from '@angular/core';
import { MovieserviceService } from '../movieservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-screen',
  templateUrl: './screen.component.html',
  styleUrls: ['./screen.component.css']
})
export class ScreenComponent implements OnInit {
  Screen: Screen = new Screen();
  submitted = false;

  constructor( private movieservice:MovieserviceService,private router:Router) { }

  ngOnInit(): void {
  }

}
