import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TheatreComponent } from './theatre/theatre.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  {
path:'theatre', 
component:TheatreComponent
},
{
path:'user',
component:UserComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
