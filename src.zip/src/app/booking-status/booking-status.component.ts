import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-status',
  templateUrl: './booking-status.component.html',
  styleUrls: ['./booking-status.component.css']
})
export class BookingStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  add()
  {
    
  }
}
