export class User
{
        userId:number;
        city:string;
        theatreName:string;
        movieName:string;
        ticket:number;
        classType:string;
        amount:number;
        seatNumber:string;

User(userId:number,city:string,theatreName:string,movieName:string,ticket:number,classType:string,amount:number,seatNumber:string)

{

    this.userId=userId;
    this.city=city;
    this.theatreName=theatreName;
    this.movieName=movieName;
    this.ticket=ticket;
    this.classType=classType;
    this.amount=amount;
    this.seatNumber=seatNumber;
}

}