import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../classes/User';

@Component({
  selector: 'app-bookticket',
  templateUrl: './bookticket.component.html',
  styleUrls: ['./bookticket.component.css']
})
export class BookticketComponent implements OnInit {

  nextpage: Observable<User[]>;

  constructor() { }

  ngOnInit(): void {
  }

}
