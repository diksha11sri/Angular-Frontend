export enum BookingStatus
{
    AVAILABLE, BOOKED, BLOCKED
}